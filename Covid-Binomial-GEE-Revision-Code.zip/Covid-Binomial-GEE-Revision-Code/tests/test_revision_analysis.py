from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.genmod.cov_struct import Exchangeable

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "analysis"))

from revision_analysis import (  # noqa: E402
    canonical_state,
    mancl_derouen_covariance,
    state_transition_counts,
    transition_probabilities,
)


def test_state_harmonization_aliases():
    assert canonical_state("NCT of Delhi") == "DELHI"
    assert canonical_state("Telengana") == "TELANGANA"
    assert canonical_state("Daman & Diu") == "DADRA AND NAGAR HAVELI AND DAMAN AND DIU"
    assert canonical_state("India") is None


def test_state_markov_does_not_bridge_missing_months():
    frame = pd.DataFrame(
        {
            "t_index": [0, 1, 3, 4],
            "prop": [0.00, 0.02, 0.03, 0.00],
        }
    )
    counts = state_transition_counts(frame, tau=0.01)
    assert counts == {"n00": 0, "n01": 1, "n10": 1, "n11": 0, "valid_pairs": 2}
    pi01, pi11 = transition_probabilities(counts)
    assert pi01 == 1.0
    assert pi11 == 0.0


def test_custom_md_matches_statsmodels_unweighted():
    rng = np.random.default_rng(42)
    rows = []
    for group in range(12):
        random_intercept = rng.normal(scale=0.35)
        for time in range(5):
            x = rng.normal()
            eta = -0.5 + 0.4 * x + random_intercept
            probability = 1 / (1 + np.exp(-eta))
            rows.append({"group": group, "time": time, "x": x, "y": rng.binomial(1, probability)})
    data = pd.DataFrame(rows)
    builtin = smf.gee(
        "y ~ x",
        groups="group",
        time="time",
        data=data,
        family=sm.families.Binomial(),
        cov_struct=Exchangeable(),
    ).fit(cov_type="bias_reduced")
    robust = smf.gee(
        "y ~ x",
        groups="group",
        time="time",
        data=data,
        family=sm.families.Binomial(),
        cov_struct=Exchangeable(),
    ).fit(cov_type="robust")
    custom = mancl_derouen_covariance(robust)
    np.testing.assert_allclose(custom, builtin.cov_params(), atol=1e-8, rtol=1e-8)
