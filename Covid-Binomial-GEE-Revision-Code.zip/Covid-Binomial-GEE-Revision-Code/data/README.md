# Data files expected by the pipeline

Place the following public-source files in this directory before running the raw-data workflow:

1. `Supplementary Table 1.csv` — district/state geolocations with `State`, `District`, `Latitude`, and `Longitude`.
2. `Modified Data (1).xlsx` — state-by-month hotspot percentage panel and climatic-zone labels.
3. `Modified Data (2).xlsx` — optional top-hotspot summary used for validation only.

The source dataset is **Cluster Interconnectedness Maps of COVID-19 Spread in India (Version 2)**, Zenodo DOI `10.5281/zenodo.7981043`.

The script also accepts a previously harmonized long panel through `--panel-long`. Required columns are state, climate, district denominator, month, and reported proportion; common spelling variants are handled deterministically.

Raw data are not bundled in the code archive. Add them to the repository only when their redistribution terms permit it.
