# COVID-19 hotspot major-revision analysis pipeline

This repository-ready pipeline supersedes the exploratory notebook used during the first manuscript draft. It performs every numerical and reproducibility task requested during major revision of the India COVID-19 hotspot manuscript.

## What the pipeline produces

1. **Final denominator-aware GEE**
   - reported state-month proportion as the primary response;
   - district count as denominator/precision weight;
   - exchangeable working correlation as primary;
   - independence and AR(1) sensitivity fits;
   - custom weighted Mancl--DeRouen bias-reduced sandwich covariance;
   - coefficient, odds-ratio, 95% confidence-interval, and omnibus climate-factor tables.

2. **Response-construction sensitivity**
   - floor, round, and ceiling implied-count constructions;
   - maximum coefficient and log-odds-ratio changes;
   - explicit flags for quasi-complete separation or unstable estimates.

3. **Influence analysis**
   - exclusion of Delhi;
   - exclusion of Maharashtra;
   - exclusion of prespecified small urban Union Territories;
   - leave-one-state-out refits and ranges for each climatic contrast.

4. **Correct state-level Markov analysis**
   - no district identities are inferred;
   - only adjacent observed months are counted;
   - all four transition counts are retained;
   - an assertion verifies that total transition counts equal valid adjacent state-month pairs;
   - states are resampled within climate groups for bootstrap confidence intervals;
   - threshold sensitivity is generated automatically.

5. **Parsimonious descriptive clustering**
   - empirical-logit adjustment `(N*p + 0.5)/(N + 1)`;
   - standardization and PCA retaining at least 90% variance;
   - diagonal-covariance Gaussian mixtures;
   - a non-degenerate selection rule requiring a minimum cluster size;
   - repeated-initialization ARI stability;
   - state-bootstrap ARI and co-clustering matrix.

6. **Manuscript-ready deliverables**
   - CSV and LaTeX tables;
   - publication-resolution figures;
   - numerical LaTeX macros and prose snippets;
   - JSON validation reports, software versions, input hashes, console previews, and a ZIP archive.

7. **LaTeX audit**
   - marked and clean manuscript generation;
   - duplicate-label and unresolved-reference checks;
   - missing figure/input/bibliography checks;
   - safe aliases for filenames containing spaces, ampersands, or other unsafe characters;
   - optional compilation of both versions.

## Important statistical implementation note

In `statsmodels`, GEE `weights` are case/observation weights. The built-in `bias_reduced` covariance path in version 0.14.x does not correctly broadcast weighted clusters in this workflow. The script therefore implements the weighted Mancl--DeRouen covariance explicitly. A mandatory run-time validation confirms that the custom implementation reproduces statsmodels' built-in unweighted bias-reduced covariance to numerical tolerance.

For exchangeable and AR(1) sensitivity fits, the working correlation is estimated from an unweighted GEE and then held fixed in the denominator-weighted mean fit. This avoids relying on weighted dependence-parameter updates that are not consistently handled across the available covariance structures. The working correlation is a nuisance parameter; all inferential covariance calculations use the weighted estimating equations.

## Installation

Python 3.11 or 3.12 is recommended.

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pytest -q
```

## Input data

Place these files in `data/`:

```text
data/
├── Supplementary Table 1.csv
├── Modified Data (1).xlsx
└── Modified Data (2).xlsx   # optional validation table
```

The monthly entries in `Modified Data (1).xlsx` are percentage points. The raw-data loader therefore divides them by 100, including entries below one percentage point. This prevents the common error of treating values such as `0.5` as a proportion of 50% rather than 0.5%.

## Run the complete paper analysis

```bash
python analysis/revision_analysis.py \
  --geo "data/Supplementary Table 1.csv" \
  --panel-wide "data/Modified Data (1).xlsx" \
  --hotspot-summary "data/Modified Data (2).xlsx" \
  --output revision_outputs \
  --primary-threshold 0.01 \
  --thresholds 0.005,0.01,0.02,0.03 \
  --bootstrap-reps 2000 \
  --cluster-bootstrap-reps 500 \
  --init-stability-runs 100 \
  --max-clusters 5 \
  --minimum-cluster-size 3 \
  --pca-variance 0.90 \
  --seed 20260714
```

The primary threshold `0.01` denotes a reported hotspot proportion of 1%. Threshold choice is not treated as scientifically unique; 0.5%, 1%, 2%, and 3% are compared by default. Change these values only with a documented scientific rationale.

For a quick development run, use the defaults or:

```bash
python analysis/revision_analysis.py \
  --geo "data/Supplementary Table 1.csv" \
  --panel-wide "data/Modified Data (1).xlsx" \
  --output revision_outputs \
  --bootstrap-reps 100 \
  --cluster-bootstrap-reps 25 \
  --init-stability-runs 20
```

A pre-harmonized long panel can be used instead:

```bash
python analysis/revision_analysis.py \
  --panel-long data/state_month_panel_long.csv \
  --output revision_outputs
```

## Output structure

```text
revision_outputs/
├── analysis_panel.csv
├── gee/
├── sensitivity/
├── markov/
├── clustering/
├── diagnostics/
├── figures/
├── tables/
│   ├── csv/
│   └── tex/
├── manuscript_ready/
├── config_used.json
├── software_and_input_manifest.json
└── run.log
```

A sibling archive named `revision_outputs_archive.zip` is created automatically.

## Reading the key outputs

- `gee/gee_primary_fractional_exchangeable.csv`: final coefficients, odds ratios, and intervals.
- `gee/gee_primary_metadata.json`: working correlation, covariance estimator, and omnibus climate test.
- `sensitivity/rounding_sensitivity_summary.json`: maximum floor/round/ceiling changes.
- `sensitivity/influence_exclusions.csv`: prespecified exclusions.
- `sensitivity/leave_one_out_ranges.csv`: leave-one-state-out ranges.
- `markov/markov_validation.json`: required transition-count assertions.
- `markov/markov_threshold_sensitivity.csv`: all threshold results and bootstrap intervals.
- `clustering/gmm_selection.csv`: BIC, ICL, minimum cluster size, and selected K.
- `clustering/gmm_stability_summary.json`: repeated-initialization and bootstrap stability.
- `manuscript_ready/revision_numeric_macros.tex`: values that can be included directly in LaTeX.

## Run the notebook

`run_revision_analysis.ipynb` is a thin, transparent runner around the command-line script. The script remains the source of truth, which prevents notebook-state dependence and makes GitHub/CI execution reproducible.

## Audit and compile marked/clean manuscripts

Place the revised manuscript at `manuscript/main.tex`, together with its bibliography and figures, then run:

```bash
python analysis/latex_audit.py \
  --tex manuscript/main.tex \
  --project-root manuscript \
  --output latex_audit_outputs \
  --compile --strict
```

Without a local LaTeX distribution, omit `--compile`; all reference and dependency checks still run.

## Reproducibility rules

- No fuzzy state matching is used. Every accepted spelling variant is explicit in `canonical_state()`.
- The script stops when no states match or when transition counts fail validation.
- Missing months are never bridged in the Markov analysis.
- Random seeds and all analysis settings are saved in `config_used.json`.
- Input SHA-256 hashes and software versions are saved in `software_and_input_manifest.json`.
- Generated results should be copied into the manuscript; hard-coded draft values should not be retained.
