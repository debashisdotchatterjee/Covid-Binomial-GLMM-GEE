#!/usr/bin/env python3
"""Reproducible major-revision analysis for the India COVID hotspot paper.

This script replaces the exploratory notebook workflow. It performs:
1. deterministic data harmonization and coverage checks;
2. denominator-weighted fractional binomial GEE;
3. Mancl--DeRouen bias-reduced sandwich covariance for weighted GEE;
4. floor/round/ceiling response-construction sensitivity;
5. exclusion and leave-one-state-out influence analyses;
6. state-level Markov transitions, state-cluster bootstrap intervals,
   threshold sensitivity, and transition-count validation;
7. empirical-logit + PCA + parsimonious diagonal-GMM clustering,
   repeated-initialization stability, and state-bootstrap co-clustering;
8. CSV, LaTeX, JSON, plots, console summaries, and a ZIP archive.

The primary response is the reported state-month proportion. District counts
enter as denominator/precision weights in the GEE score. Integer reconstructions
are sensitivity analyses only.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import math
import os
import platform
import re
import shutil
import sys
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import patsy
import scipy
from scipy.stats import chi2, norm
import sklearn
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
import statsmodels
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.genmod.cov_struct import Autoregressive, Exchangeable, Independence

LOGGER = logging.getLogger("revision_analysis")

MONTH_ORDER = [f"2020-{m:02d}" for m in range(3, 13)]
MONTH_INDEX = {m: i for i, m in enumerate(MONTH_ORDER)}
REFERENCE_CLIMATE = "Humid Subtropical"
CLIMATE_ORDER = [
    "Humid Subtropical",
    "Arid/Semi-Arid",
    "Montane",
    "Tropical Monsoon",
    "Tropical Savannah",
]
CLIMATE_TERM_PREFIX = "C(climate_family, Treatment(reference='Humid Subtropical'))"
FORMULA = (
    "response ~ "
    "C(climate_family, Treatment(reference='Humid Subtropical')) + "
    "C(month, Treatment(reference='2020-03'))"
)


@dataclass(frozen=True)
class RunConfig:
    start_month: str = "2020-03"
    end_month: str = "2020-12"
    primary_threshold: float = 0.01
    thresholds: tuple[float, ...] = (0.005, 0.01, 0.02, 0.03)
    bootstrap_reps: int = 1000
    cluster_bootstrap_reps: int = 100
    init_stability_runs: int = 30
    max_clusters: int = 5
    minimum_cluster_size: int = 3
    pca_variance: float = 0.90
    random_seed: int = 20260714
    show_plots: bool = False


# ---------------------------------------------------------------------------
# General utilities
# ---------------------------------------------------------------------------

def setup_logging(output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    LOGGER.setLevel(logging.INFO)
    LOGGER.handlers.clear()
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    file_handler = logging.FileHandler(output_dir / "run.log", mode="w", encoding="utf-8")
    file_handler.setFormatter(formatter)
    LOGGER.addHandler(console)
    LOGGER.addHandler(file_handler)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def safe_slug(value: str) -> str:
    value = value.replace("&", " and ")
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value.strip())
    value = re.sub(r"_+", "_", value).strip("_")
    return value or "item"


def console_table(title: str, frame: pd.DataFrame, rows: int = 25) -> None:
    LOGGER.info("\n%s\n%s", title, frame.head(rows).to_string(index=False))
    if len(frame) > rows:
        LOGGER.info("... %d additional rows written to disk.", len(frame) - rows)


def save_frame(
    frame: pd.DataFrame,
    name: str,
    output_dir: Path,
    *,
    caption: str | None = None,
    label: str | None = None,
    index: bool = False,
    float_format: str = "%.4f",
) -> None:
    csv_dir = output_dir / "tables" / "csv"
    tex_dir = output_dir / "tables" / "tex"
    csv_dir.mkdir(parents=True, exist_ok=True)
    tex_dir.mkdir(parents=True, exist_ok=True)
    frame.to_csv(csv_dir / f"{name}.csv", index=index)
    latex = frame.to_latex(
        index=index,
        escape=True,
        longtable=len(frame) > 35,
        caption=caption,
        label=label,
        float_format=float_format,
        na_rep="--",
    )
    (tex_dir / f"{name}.tex").write_text(latex, encoding="utf-8")


def finish_plot(path: Path, show: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    if show:
        plt.show()
    plt.close()


# ---------------------------------------------------------------------------
# Deterministic state and climate harmonization
# ---------------------------------------------------------------------------

def canonical_state(value: Any) -> str | None:
    if pd.isna(value):
        return None
    s = str(value).strip()
    if not s:
        return None
    s = s.replace("&", " AND ")
    s = re.sub(r"[^A-Za-z0-9]+", " ", s).upper()
    s = re.sub(r"\s+", " ", s).strip()
    if s in {"TOTAL", "INDIA", "NAN", "NONE"}:
        return None
    aliases = {
        "ANDAMAN NICOBAR": "ANDAMAN AND NICOBAR ISLANDS",
        "ANDAMAN AND NICOBAR": "ANDAMAN AND NICOBAR ISLANDS",
        "ANDAMAN NICOBAR ISLANDS": "ANDAMAN AND NICOBAR ISLANDS",
        "CHHATTISHGARH": "CHHATTISGARH",
        "NCT OF DELHI": "DELHI",
        "NATIONAL CAPITAL TERRITORY OF DELHI": "DELHI",
        "DELHI NCT": "DELHI",
        "ORISSA": "ODISHA",
        "PONDICHERRY": "PUDUCHERRY",
        "UTTARANCHAL": "UTTARAKHAND",
        "TELENGANA": "TELANGANA",
        "TAMILNADU": "TAMIL NADU",
        "JAMMU KASHMIR": "JAMMU AND KASHMIR",
        "JAMMU AND KASHMIR UT": "JAMMU AND KASHMIR",
        "DADRA NAGAR HAVELI": "DADRA AND NAGAR HAVELI AND DAMAN AND DIU",
        "DADRA AND NAGAR HAVELI": "DADRA AND NAGAR HAVELI AND DAMAN AND DIU",
        "DAMAN DIU": "DADRA AND NAGAR HAVELI AND DAMAN AND DIU",
        "DAMAN AND DIU": "DADRA AND NAGAR HAVELI AND DAMAN AND DIU",
        "DAMAN AND DIU AND DADRA AND NAGAR HAVELI": "DADRA AND NAGAR HAVELI AND DAMAN AND DIU",
        "DADRA AND NAGAR HAVELI AND DAMAN AND DIU": "DADRA AND NAGAR HAVELI AND DAMAN AND DIU",
    }
    return aliases.get(s, s)


def display_state_from_key(key: str) -> str:
    special = {
        "ANDAMAN AND NICOBAR ISLANDS": "Andaman & Nicobar",
        "DADRA AND NAGAR HAVELI AND DAMAN AND DIU": "Dadra and Nagar Haveli and Daman and Diu",
        "JAMMU AND KASHMIR": "Jammu and Kashmir",
        "TAMIL NADU": "Tamil Nadu",
    }
    return special.get(key, key.title())


def climate_family(label: Any) -> str | None:
    if pd.isna(label):
        return None
    s = re.sub(r"\s+", " ", str(label).strip()).lower()
    s = s.replace("montanne", "montane").replace("savanna ", "savannah ")
    if s.startswith("humid subtropical"):
        return "Humid Subtropical"
    if s.startswith("arid") or s.startswith("hot desert") or s.startswith("hot deserts"):
        return "Arid/Semi-Arid"
    if s.startswith("montane"):
        return "Montane"
    if s.startswith("tropical monsoon"):
        return "Tropical Monsoon"
    if s.startswith("tropical savannah") or s.startswith("tropical savanna"):
        return "Tropical Savannah"
    return None


def find_column(columns: Sequence[Any], predicates: Sequence[str]) -> Any | None:
    for col in columns:
        low = str(col).strip().lower()
        if any(token in low for token in predicates):
            return col
    return None


def parse_month_header(value: Any) -> str | None:
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m")
    text = str(value).strip()
    match = re.search(
        r"(march|april|may|june|july|august|september|october|november|december)\s+2020",
        text,
        flags=re.IGNORECASE,
    )
    if match:
        month_number = {
            "march": 3,
            "april": 4,
            "may": 5,
            "june": 6,
            "july": 7,
            "august": 8,
            "september": 9,
            "october": 10,
            "november": 11,
            "december": 12,
        }[match.group(1).lower()]
        return f"2020-{month_number:02d}"
    try:
        parsed = pd.to_datetime(text, errors="raise")
        return parsed.strftime("%Y-%m")
    except Exception:
        return None


def coerce_proportion(value: Any) -> float:
    if pd.isna(value):
        return np.nan
    text = str(value).replace("%", "").replace(",", "").strip()
    try:
        number = float(text)
    except ValueError:
        return np.nan
    if number < 0:
        return np.nan
    return number / 100.0 if number > 1 else number


def coerce_percentage(value: Any) -> float:
    """Convert a source cell expressed in percentage points to [0,1]."""
    if pd.isna(value):
        return np.nan
    text = str(value).replace("%", "").replace(",", "").strip()
    try:
        number = float(text)
    except ValueError:
        return np.nan
    if number < 0:
        return np.nan
    return number / 100.0


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_geolocation(path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    raw = pd.read_csv(path)
    state_col = find_column(raw.columns, ["state", "states", "ut"])
    district_col = find_column(raw.columns, ["district"])
    lat_col = find_column(raw.columns, ["latitude", "lat"])
    lon_col = find_column(raw.columns, ["longitude", "lon", "lng"])
    if any(col is None for col in (state_col, district_col, lat_col, lon_col)):
        raise ValueError(f"Could not identify required geolocation columns: {list(raw.columns)}")

    geo = raw.rename(
        columns={state_col: "state_raw", district_col: "district", lat_col: "latitude", lon_col: "longitude"}
    ).copy()
    geo["state_key"] = geo["state_raw"].map(canonical_state)
    geo["district"] = geo["district"].astype(str).str.strip()
    geo["latitude"] = pd.to_numeric(geo["latitude"], errors="coerce")
    geo["longitude"] = pd.to_numeric(geo["longitude"], errors="coerce")
    geo = geo.dropna(subset=["state_key", "district", "latitude", "longitude"])
    geo = geo[(geo["latitude"].between(5, 40)) & (geo["longitude"].between(65, 100))]
    duplicates = geo.duplicated(["state_key", "district"], keep=False)
    duplicate_rows = geo.loc[duplicates].sort_values(["state_key", "district"])
    geo = geo.drop_duplicates(["state_key", "district"], keep="first")

    summary = (
        geo.groupby("state_key", as_index=False)
        .agg(
            N_s=("district", "nunique"),
            lat_centroid=("latitude", "mean"),
            lon_centroid=("longitude", "mean"),
        )
    )
    summary["state"] = summary["state_key"].map(display_state_from_key)
    return summary, duplicate_rows


def load_wide_panel(path: Path, start_month: str, end_month: str) -> pd.DataFrame:
    book = pd.ExcelFile(path)
    chosen: pd.DataFrame | None = None
    chosen_months: dict[Any, str] = {}
    for sheet_name in book.sheet_names:
        test = pd.read_excel(path, sheet_name=sheet_name)
        month_columns = {col: parse_month_header(col) for col in test.columns}
        month_columns = {col: month for col, month in month_columns.items() if month is not None}
        month_columns = {
            col: month for col, month in month_columns.items() if start_month <= month <= end_month
        }
        if len(month_columns) > len(chosen_months):
            chosen, chosen_months = test, month_columns
    if chosen is None or not chosen_months:
        raise ValueError(f"No March--December 2020 month columns found in {path}")

    state_col = find_column(chosen.columns, ["states and union", "states", "state"])
    climate_col = find_column(chosen.columns, ["climatic", "climate", "koppen", "zone"])
    if state_col is None or climate_col is None:
        raise ValueError(f"Could not identify state/climate columns: {list(chosen.columns)}")

    keep = [state_col, climate_col] + list(chosen_months)
    panel = chosen[keep].copy()
    panel = panel.rename(columns={state_col: "state_raw", climate_col: "climate"})
    panel["state_key"] = panel["state_raw"].map(canonical_state)
    panel = panel.dropna(subset=["state_key"])
    panel = panel[~panel["state_key"].isin({"TOTAL", "INDIA"})]

    long_parts: list[pd.DataFrame] = []
    for col, month in chosen_months.items():
        part = panel[["state_raw", "state_key", "climate", col]].copy()
        part = part.rename(columns={col: "source_percentage"})
        part["month"] = month
        part["prop"] = part["source_percentage"].map(coerce_percentage)
        long_parts.append(part)
    long = pd.concat(long_parts, ignore_index=True)
    long = long[long["month"].between(start_month, end_month)]
    long["state"] = long["state_key"].map(display_state_from_key)
    return long


def load_harmonized_panel(path: Path) -> pd.DataFrame:
    panel = pd.read_csv(path)
    required = {"state", "climate", "N_s", "month", "prop"}
    missing = required.difference(panel.columns)
    if missing:
        raise ValueError(f"Harmonized panel is missing columns: {sorted(missing)}")
    panel = panel.copy()
    panel["state_key"] = panel.get("state_norm", panel["state"]).map(canonical_state)
    panel["state"] = panel["state_key"].map(display_state_from_key)
    panel["N_s"] = pd.to_numeric(panel["N_s"], errors="coerce")
    panel["prop"] = pd.to_numeric(panel["prop"], errors="coerce")
    panel["month"] = panel["month"].astype(str).str.slice(0, 7)
    return panel


def build_analysis_panel(
    *,
    geo_path: Path | None,
    wide_panel_path: Path | None,
    long_panel_path: Path | None,
    output_dir: Path,
    config: RunConfig,
) -> pd.DataFrame:
    diagnostics_dir = output_dir / "diagnostics"
    diagnostics_dir.mkdir(parents=True, exist_ok=True)

    if long_panel_path is not None:
        panel = load_harmonized_panel(long_panel_path)
        duplicate_geo = pd.DataFrame()
    else:
        if geo_path is None or wide_panel_path is None:
            raise ValueError("Provide either --panel-long, or both --geo and --panel-wide.")
        geo_summary, duplicate_geo = load_geolocation(geo_path)
        panel_raw = load_wide_panel(wide_panel_path, config.start_month, config.end_month)
        panel_states = set(panel_raw["state_key"].dropna())
        geo_states = set(geo_summary["state_key"].dropna())
        mismatch = pd.DataFrame(
            {
                "panel_not_geo": pd.Series(sorted(panel_states - geo_states), dtype="object"),
                "geo_not_panel": pd.Series(sorted(geo_states - panel_states), dtype="object"),
            }
        )
        mismatch.to_csv(diagnostics_dir / "state_name_mismatches.csv", index=False)
        if not duplicate_geo.empty:
            duplicate_geo.to_csv(diagnostics_dir / "duplicate_geolocation_rows.csv", index=False)
        panel = panel_raw.merge(geo_summary, on=["state_key", "state"], how="left", validate="many_to_one")

    panel = panel[panel["month"].between(config.start_month, config.end_month)].copy()
    panel["climate_family"] = panel["climate"].map(climate_family)
    panel["t_index"] = panel["month"].map(MONTH_INDEX)
    panel["N_s"] = pd.to_numeric(panel["N_s"], errors="coerce")
    panel["prop"] = pd.to_numeric(panel["prop"], errors="coerce")
    panel["state"] = panel["state_key"].map(display_state_from_key)

    exclusion_reason = pd.Series("", index=panel.index, dtype="object")
    exclusion_reason.loc[panel["N_s"].isna()] = "missing denominator"
    exclusion_reason.loc[panel["climate_family"].isna()] = "unmapped climatic label"
    exclusion_reason.loc[panel["prop"].isna()] = "missing proportion"
    exclusion_reason.loc[~panel["prop"].between(0, 1, inclusive="both")] = "proportion outside [0,1]"
    exclusion_reason.loc[panel["t_index"].isna()] = "month outside analysis window"
    excluded = panel.loc[exclusion_reason.ne("")].copy()
    excluded["exclusion_reason"] = exclusion_reason.loc[excluded.index]
    excluded.to_csv(diagnostics_dir / "excluded_rows.csv", index=False)
    panel = panel.loc[exclusion_reason.eq("")].copy()

    duplicate_state_month = panel.duplicated(["state_key", "month"], keep=False)
    if duplicate_state_month.any():
        dup = panel.loc[duplicate_state_month].sort_values(["state_key", "month"])
        dup.to_csv(diagnostics_dir / "duplicate_state_month_rows.csv", index=False)
        raise ValueError("Duplicate state-month rows detected; see diagnostics/duplicate_state_month_rows.csv")

    panel["climate_family"] = pd.Categorical(panel["climate_family"], CLIMATE_ORDER, ordered=True)
    panel["month"] = pd.Categorical(panel["month"], MONTH_ORDER, ordered=True)
    panel = panel.sort_values(["state", "t_index"]).reset_index(drop=True)

    if panel.empty:
        raise ValueError("No valid state-month rows remain after harmonization.")
    if panel["state"].nunique() < 20:
        raise ValueError(f"Only {panel['state'].nunique()} states matched; inspect diagnostics before analysis.")
    group_sizes = panel.groupby("climate_family", observed=True)["state"].nunique()
    if REFERENCE_CLIMATE not in group_sizes.index:
        raise ValueError(f"Reference climate '{REFERENCE_CLIMATE}' is absent.")
    if (group_sizes < 2).any():
        LOGGER.warning("At least one climatic family contains fewer than two states: %s", group_sizes.to_dict())

    panel.to_csv(output_dir / "analysis_panel.csv", index=False)
    return panel


def validate_hotspot_summary(summary_path: Path, panel: pd.DataFrame, output_dir: Path) -> None:
    """Compare optional top-four monthly summary against the extracted panel."""
    raw = pd.read_excel(summary_path)
    if raw.empty or len(raw.columns) < 3:
        return
    month_col = raw.columns[0]
    records: list[dict[str, Any]] = []
    for _, row in raw.iterrows():
        try:
            month = pd.to_datetime(row[month_col], origin="1899-12-30", unit="D").strftime("%Y-%m")
        except Exception:
            try:
                month = pd.to_datetime(row[month_col]).strftime("%Y-%m")
            except Exception:
                continue
        if month not in MONTH_ORDER:
            continue
        for rank, (state_position, pct_position) in enumerate(((1, 2), (4, 6), (7, 9), (10, 12)), start=1):
            if state_position >= len(raw.columns) or pct_position >= len(raw.columns):
                continue
            records.append(
                {
                    "month": month,
                    "rank": rank,
                    "summary_state_key": canonical_state(row.iloc[state_position]),
                    "summary_percentage": pd.to_numeric(row.iloc[pct_position], errors="coerce"),
                }
            )
    provided = pd.DataFrame(records)
    if provided.empty:
        return
    expected = panel.copy()
    expected["rank"] = expected.groupby("month", observed=True)["prop"].rank(method="first", ascending=False)
    expected = expected[expected["rank"] <= 4][["month", "rank", "state_key", "prop"]]
    expected["rank"] = expected["rank"].astype(int)
    check = provided.merge(expected, on=["month", "rank"], how="outer")
    check["state_match"] = check["summary_state_key"].eq(check["state_key"])
    check["percentage_difference"] = check["summary_percentage"] - 100 * check["prop"]
    check.to_csv(output_dir / "diagnostics" / "hotspot_summary_validation.csv", index=False)


# ---------------------------------------------------------------------------
# Weighted GEE and Mancl--DeRouen covariance
# ---------------------------------------------------------------------------

def mancl_derouen_covariance(result: Any) -> np.ndarray:
    """Weighted Mancl--DeRouen bias-reduced sandwich covariance.

    statsmodels 0.14.x implements the unweighted correction but its built-in
    path broadcasts observation weights against parameter scores. This
    implementation places the diagonal observation-weight matrix inside the
    estimating equations and reduces exactly to statsmodels' implementation
    when weights are absent.
    """
    model = result.model
    cov_naive = np.asarray(result.cov_naive, dtype=float).copy()
    scaling_factor = float(getattr(model, "scaling_factor", 1.0))
    cov_naive_unscaled = cov_naive / scaling_factor
    scale = float(model.estimate_scale())
    bcm = np.zeros_like(cov_naive_unscaled)

    for i in range(model.num_group):
        expval, linear_predictor = model.cached_means[i]
        residual = model.endog_li[i] - expval
        dmat = model.mean_deriv(model.exog_li[i], linear_predictor)
        sdev = np.sqrt(model.family.variance(expval))
        vinv_d = model.cov_struct.covariance_matrix_solve(expval, i, sdev, (dmat,))[0] / scale
        if model.weights is None:
            weights = np.ones(len(residual), dtype=float)
        else:
            weights = np.asarray(model.weights_li[i], dtype=float)

        # H_i = D_i B^{-1} D_i' V_i^{-1} W_i.
        weighted_vinv_d = weights[:, None] * vinv_d
        leverage = dmat @ cov_naive_unscaled @ weighted_vinv_d.T
        identity_minus_h = np.eye(len(residual)) - leverage
        try:
            adjusted_residual = np.linalg.solve(identity_minus_h, residual)
        except np.linalg.LinAlgError:
            adjusted_residual = np.linalg.pinv(identity_minus_h) @ residual

        vinv_weighted_residual = model.cov_struct.covariance_matrix_solve(
            expval,
            i,
            sdev,
            (weights * adjusted_residual,),
        )[0] / scale
        adjusted_cluster_score = dmat.T @ vinv_weighted_residual
        bcm += np.outer(adjusted_cluster_score, adjusted_cluster_score)

    covariance = cov_naive_unscaled @ bcm @ cov_naive_unscaled
    covariance *= scaling_factor
    if not np.all(np.isfinite(covariance)):
        raise FloatingPointError("Non-finite Mancl--DeRouen covariance.")
    return covariance


def validate_md_implementation(panel: pd.DataFrame) -> float:
    """Validate custom MD covariance against statsmodels in the unweighted case."""
    data = panel.copy()
    data["response"] = data["prop"]
    unweighted_model = smf.gee(
        FORMULA,
        groups="state",
        time="t_index",
        data=data,
        family=sm.families.Binomial(),
        cov_struct=Exchangeable(),
    )
    builtin = unweighted_model.fit(cov_type="bias_reduced", maxiter=200)
    robust = smf.gee(
        FORMULA,
        groups="state",
        time="t_index",
        data=data,
        family=sm.families.Binomial(),
        cov_struct=Exchangeable(),
    ).fit(cov_type="robust", maxiter=200)
    custom = mancl_derouen_covariance(robust)
    error = float(np.max(np.abs(custom - np.asarray(builtin.cov_params()))))
    if error > 1e-8:
        raise AssertionError(f"Custom MD covariance validation failed: max error={error:g}")
    return error


def make_covariance_structure(name: str) -> Any:
    if name == "exchangeable":
        return Exchangeable()
    if name == "independence":
        return Independence()
    if name == "ar1":
        return Autoregressive(grid=True)
    raise ValueError(f"Unknown covariance structure: {name}")


def fit_weighted_gee(
    panel: pd.DataFrame,
    *,
    response: pd.Series,
    covariance_name: str,
    use_md_covariance: bool = True,
) -> tuple[Any, np.ndarray, dict[str, Any]]:
    data = panel.copy()
    data["response"] = np.asarray(response, dtype=float)
    data = data.dropna(subset=["response", "N_s", "state", "climate_family", "month", "t_index"])
    data["climate_family"] = pd.Categorical(data["climate_family"], CLIMATE_ORDER, ordered=True)
    data["month"] = pd.Categorical(data["month"], MONTH_ORDER, ordered=True)

    metadata: dict[str, Any] = {"covariance": covariance_name, "n_obs": len(data), "n_states": data["state"].nunique()}
    update_dep = True
    structure = make_covariance_structure(covariance_name)

    if covariance_name in {"exchangeable", "ar1"}:
        # In statsmodels 0.14.x, weighted dependence-parameter updates are not
        # reliable for these structures (AR1 explicitly ignores weights, and
        # Exchangeable indexes the unsplit weight vector). The working
        # correlation is a nuisance quantity, so estimate it in an unweighted
        # GEE and hold it fixed in the denominator-weighted mean model.
        unweighted_structure = (
            Autoregressive(grid=True) if covariance_name == "ar1" else Exchangeable()
        )
        unweighted = smf.gee(
            FORMULA,
            groups="state",
            time="t_index",
            data=data,
            family=sm.families.Binomial(),
            cov_struct=unweighted_structure,
        ).fit(
            cov_type="robust",
            maxiter=250,
            first_dep_update=10 if covariance_name == "ar1" else 0,
        )
        rho = float(np.asarray(unweighted.cov_struct.dep_params).squeeze())
        structure = Autoregressive(grid=True) if covariance_name == "ar1" else Exchangeable()
        model = smf.gee(
            FORMULA,
            groups="state",
            time="t_index",
            data=data,
            family=sm.families.Binomial(),
            cov_struct=structure,
            weights=data["N_s"].astype(float),
            update_dep=False,
        )
        model.cov_struct.dep_params = rho
        update_dep = False
        metadata["working_correlation"] = rho
        metadata["working_correlation_note"] = (
            f"Estimated by unweighted {covariance_name} GEE and fixed in weighted fit."
        )
    else:
        model = smf.gee(
            FORMULA,
            groups="state",
            time="t_index",
            data=data,
            family=sm.families.Binomial(),
            cov_struct=structure,
            weights=data["N_s"].astype(float),
            update_dep=update_dep,
        )

    result = model.fit(cov_type="robust", maxiter=250, first_dep_update=10 if covariance_name == "ar1" else 0)
    covariance = mancl_derouen_covariance(result) if use_md_covariance else np.asarray(result.cov_params())
    dep = getattr(result.cov_struct, "dep_params", None)
    if dep is not None:
        metadata["working_correlation"] = float(np.asarray(dep).squeeze())
    metadata["converged"] = bool(getattr(result, "converged", True))
    metadata["covariance_estimator"] = "Mancl-DeRouen bias-reduced sandwich" if use_md_covariance else "Liang-Zeger robust sandwich"
    return result, covariance, metadata


def gee_table(result: Any, covariance: np.ndarray) -> pd.DataFrame:
    terms = list(result.params.index)
    estimates = np.asarray(result.params, dtype=float)
    standard_errors = np.sqrt(np.clip(np.diag(covariance), 0, np.inf))
    z_values = estimates / standard_errors
    p_values = 2 * norm.sf(np.abs(z_values))
    lower = estimates - 1.96 * standard_errors
    upper = estimates + 1.96 * standard_errors
    return pd.DataFrame(
        {
            "term": terms,
            "coef": estimates,
            "se": standard_errors,
            "z": z_values,
            "p": p_values,
            "OR": np.exp(np.clip(estimates, -700, 700)),
            "OR_lo": np.exp(np.clip(lower, -700, 700)),
            "OR_hi": np.exp(np.clip(upper, -700, 700)),
        }
    )


def climate_rows(table: pd.DataFrame) -> pd.DataFrame:
    return table[table["term"].str.startswith(CLIMATE_TERM_PREFIX, na=False)].copy()


def omnibus_climate_test(result: Any, covariance: np.ndarray) -> dict[str, float]:
    terms = list(result.params.index)
    indices = [i for i, term in enumerate(terms) if term.startswith(CLIMATE_TERM_PREFIX)]
    beta = np.asarray(result.params, dtype=float)[indices]
    cov = covariance[np.ix_(indices, indices)]
    statistic = float(beta.T @ np.linalg.pinv(cov) @ beta)
    degrees = len(indices)
    return {"chi2": statistic, "df": degrees, "p": float(chi2.sf(statistic, degrees))}


def friendly_term(term: str) -> str:
    if term == "Intercept":
        return "Intercept"
    climate_match = re.search(r"\[T\.(.+)\]$", term) if term.startswith("C(climate_family") else None
    if climate_match:
        return f"Climate: {climate_match.group(1)}"
    month_match = re.search(r"\[T\.(\d{4}-\d{2})\]$", term) if term.startswith("C(month") else None
    if month_match:
        return f"Month: {month_match.group(1)}"
    return term


def run_gee_analyses(panel: pd.DataFrame, output_dir: Path) -> dict[str, Any]:
    results_dir = output_dir / "gee"
    results_dir.mkdir(parents=True, exist_ok=True)

    validation_error = validate_md_implementation(panel)
    LOGGER.info("Validated weighted MD implementation against unweighted statsmodels path; max absolute error %.3g", validation_error)

    primary_result, primary_cov, primary_meta = fit_weighted_gee(
        panel,
        response=panel["prop"],
        covariance_name="exchangeable",
    )
    primary_table = gee_table(primary_result, primary_cov)
    primary_table["friendly_term"] = primary_table["term"].map(friendly_term)
    primary_table.to_csv(results_dir / "gee_primary_fractional_exchangeable.csv", index=False)
    omnibus = omnibus_climate_test(primary_result, primary_cov)
    write_json(results_dir / "gee_primary_metadata.json", {**primary_meta, "omnibus_climate": omnibus, "md_validation_error": validation_error})
    console_table("Primary denominator-weighted fractional GEE", primary_table)

    work_tables: list[pd.DataFrame] = []
    work_meta: dict[str, Any] = {}
    for name in ("exchangeable", "ar1", "independence"):
        result, covariance, metadata = fit_weighted_gee(
            panel,
            response=panel["prop"],
            covariance_name=name,
        )
        table = gee_table(result, covariance)
        table.insert(0, "working_correlation", name)
        work_tables.append(table)
        work_meta[name] = metadata
    working = pd.concat(work_tables, ignore_index=True)
    working.to_csv(results_dir / "gee_working_correlation_sensitivity.csv", index=False)
    write_json(results_dir / "gee_working_correlation_metadata.json", work_meta)

    climate_primary = climate_rows(primary_table).copy()
    climate_primary["friendly_term"] = climate_primary["term"].map(friendly_term)
    save_frame(
        climate_primary[["friendly_term", "coef", "se", "z", "p", "OR", "OR_lo", "OR_hi"]],
        "gee_primary_climate_contrasts",
        output_dir,
        caption="Primary denominator-weighted fractional GEE climatic-family contrasts.",
        label="tab:gee_primary_climate",
    )

    plt.figure(figsize=(8, 5))
    plot_frame = climate_primary.iloc[::-1]
    y = np.arange(len(plot_frame))
    plt.errorbar(
        plot_frame["OR"],
        y,
        xerr=np.vstack([plot_frame["OR"] - plot_frame["OR_lo"], plot_frame["OR_hi"] - plot_frame["OR"]]),
        fmt="o",
        capsize=4,
    )
    plt.axvline(1.0, linestyle="--")
    plt.yticks(y, plot_frame["friendly_term"].str.replace("Climate: ", "", regex=False))
    plt.xscale("log")
    plt.xlabel("Population-average odds ratio (log scale)")
    plt.title("Primary climatic-family GEE contrasts")
    finish_plot(output_dir / "figures" / "gee_primary_forest.png", False)

    return {
        "primary_result": primary_result,
        "primary_cov": primary_cov,
        "primary_table": primary_table,
        "primary_meta": primary_meta,
        "omnibus": omnibus,
        "working_table": working,
    }


# ---------------------------------------------------------------------------
# Integer construction sensitivity and influence analysis
# ---------------------------------------------------------------------------

def constructed_response(panel: pd.DataFrame, method: str) -> pd.Series:
    raw = panel["N_s"].astype(float) * panel["prop"].astype(float)
    if method == "floor":
        counts = np.floor(raw)
    elif method == "round":
        counts = np.floor(raw + 0.5)  # deterministic half-up rounding
    elif method == "ceil":
        counts = np.ceil(raw)
    else:
        raise ValueError(method)
    counts = np.clip(counts, 0, panel["N_s"].astype(float))
    return counts / panel["N_s"].astype(float)


def run_rounding_sensitivity(
    panel: pd.DataFrame,
    primary_table: pd.DataFrame,
    output_dir: Path,
) -> dict[str, Any]:
    sensitivity_dir = output_dir / "sensitivity"
    sensitivity_dir.mkdir(parents=True, exist_ok=True)
    tables: list[pd.DataFrame] = []
    for method in ("floor", "round", "ceil"):
        result, covariance, metadata = fit_weighted_gee(
            panel,
            response=constructed_response(panel, method),
            covariance_name="exchangeable",
        )
        table = gee_table(result, covariance)
        table.insert(0, "construction", method)
        table["separation_flag"] = (
            table["coef"].abs().gt(10)
            | table["OR"].lt(1e-6)
            | table["OR"].gt(1e6)
            | ~np.isfinite(table["se"])
        )
        table.to_csv(sensitivity_dir / f"gee_{method}.csv", index=False)
        write_json(sensitivity_dir / f"gee_{method}_metadata.json", metadata)
        tables.append(table)

    combined = pd.concat(tables, ignore_index=True)
    primary_climate = climate_rows(primary_table).set_index("term")
    climate_combined = climate_rows(combined).copy()
    climate_combined["primary_coef"] = climate_combined["term"].map(primary_climate["coef"])
    climate_combined["primary_OR"] = climate_combined["term"].map(primary_climate["OR"])
    climate_combined["abs_coef_change"] = (climate_combined["coef"] - climate_combined["primary_coef"]).abs()
    climate_combined["abs_log_OR_change"] = np.abs(np.log(climate_combined["OR"]) - np.log(climate_combined["primary_OR"]))
    climate_combined.to_csv(sensitivity_dir / "rounding_sensitivity_climate.csv", index=False)

    finite = climate_combined.loc[~climate_combined["separation_flag"] & np.isfinite(climate_combined["abs_log_OR_change"])]
    summary = {
        "max_abs_coefficient_change_all": float(climate_combined["abs_coef_change"].max()),
        "max_abs_log_OR_change_all": float(climate_combined["abs_log_OR_change"].max()),
        "max_abs_coefficient_change_nonseparated": float(finite["abs_coef_change"].max()) if not finite.empty else None,
        "max_abs_log_OR_change_nonseparated": float(finite["abs_log_OR_change"].max()) if not finite.empty else None,
        "separation_terms": climate_combined.loc[climate_combined["separation_flag"], ["construction", "term"]].to_dict("records"),
    }
    write_json(sensitivity_dir / "rounding_sensitivity_summary.json", summary)
    console_table("Floor/round/ceiling climate sensitivity", climate_combined)

    pivot = pd.concat(
        [
            climate_rows(primary_table).assign(construction="fractional"),
            climate_rows(combined),
        ],
        ignore_index=True,
    )
    pivot["friendly_term"] = pivot["term"].map(friendly_term)
    pivot_table = pivot.pivot(index="construction", columns="friendly_term", values="OR").reset_index()
    save_frame(
        pivot_table,
        "rounding_sensitivity_odds_ratios",
        output_dir,
        caption="Climatic-family odds ratios under fractional, floor, round, and ceiling response constructions.",
        label="tab:rounding_sensitivity",
    )
    return {"combined": climate_combined, "summary": summary, "pivot": pivot_table}


def fit_climate_only_for_subset(panel: pd.DataFrame) -> pd.DataFrame:
    result, covariance, _ = fit_weighted_gee(
        panel,
        response=panel["prop"],
        covariance_name="exchangeable",
    )
    table = climate_rows(gee_table(result, covariance)).copy()
    return table


def run_influence_analyses(panel: pd.DataFrame, output_dir: Path) -> dict[str, pd.DataFrame]:
    sensitivity_dir = output_dir / "sensitivity"
    sensitivity_dir.mkdir(parents=True, exist_ok=True)
    analyses = {
        "Exclude Delhi": {"Delhi"},
        "Exclude Maharashtra": {"Maharashtra"},
        "Exclude small urban UTs": {"Delhi", "Chandigarh", "Puducherry"},
    }
    exclusion_tables: list[pd.DataFrame] = []
    for name, states in analyses.items():
        subset = panel.loc[~panel["state"].isin(states)].copy()
        table = fit_climate_only_for_subset(subset)
        table.insert(0, "analysis", name)
        exclusion_tables.append(table)
    exclusion = pd.concat(exclusion_tables, ignore_index=True)
    exclusion.to_csv(sensitivity_dir / "influence_exclusions.csv", index=False)
    console_table("Pre-specified exclusion analyses", exclusion)

    loo_tables: list[pd.DataFrame] = []
    for state in sorted(panel["state"].unique()):
        subset = panel.loc[panel["state"].ne(state)].copy()
        try:
            table = fit_climate_only_for_subset(subset)
            table.insert(0, "left_out", state)
            table["fit_error"] = ""
        except Exception as exc:
            LOGGER.warning("Leave-one-state-out fit failed for %s: %s", state, exc)
            table = pd.DataFrame(
                {
                    "left_out": [state],
                    "term": [""],
                    "coef": [np.nan],
                    "se": [np.nan],
                    "z": [np.nan],
                    "p": [np.nan],
                    "OR": [np.nan],
                    "OR_lo": [np.nan],
                    "OR_hi": [np.nan],
                    "fit_error": [str(exc)],
                }
            )
        loo_tables.append(table)
    loo = pd.concat(loo_tables, ignore_index=True)
    loo.to_csv(sensitivity_dir / "leave_one_state_out.csv", index=False)
    valid = loo.loc[loo["term"].str.startswith(CLIMATE_TERM_PREFIX, na=False)].copy()
    ranges = (
        valid.groupby("term", as_index=False)
        .agg(
            OR_min=("OR", "min"),
            OR_max=("OR", "max"),
            CIlo_min=("OR_lo", "min"),
            CIlo_max=("OR_lo", "max"),
            CIhi_min=("OR_hi", "min"),
            CIhi_max=("OR_hi", "max"),
            successful_fits=("OR", "count"),
        )
    )
    ranges["friendly_term"] = ranges["term"].map(friendly_term)
    ranges.to_csv(sensitivity_dir / "leave_one_out_ranges.csv", index=False)
    save_frame(
        ranges[["friendly_term", "OR_min", "OR_max", "CIlo_min", "CIlo_max", "CIhi_min", "CIhi_max", "successful_fits"]],
        "leave_one_out_ranges",
        output_dir,
        caption="Leave-one-state-out ranges for principal climatic-family odds ratios and confidence limits.",
        label="tab:leave_one_out",
    )
    return {"exclusions": exclusion, "leave_one_out": loo, "ranges": ranges}


# ---------------------------------------------------------------------------
# State-level Markov transitions and bootstrap
# ---------------------------------------------------------------------------

def state_transition_counts(state_frame: pd.DataFrame, tau: float) -> dict[str, int]:
    ordered = state_frame.sort_values("t_index")
    z = (ordered["prop"].to_numpy(dtype=float) >= tau).astype(int)
    time = ordered["t_index"].to_numpy(dtype=int)
    counts = {"n00": 0, "n01": 0, "n10": 0, "n11": 0, "valid_pairs": 0}
    for index in range(1, len(z)):
        if time[index] - time[index - 1] != 1:
            continue
        key = f"n{z[index - 1]}{z[index]}"
        counts[key] += 1
        counts["valid_pairs"] += 1
    return counts


def transition_probabilities(counts: Mapping[str, int]) -> tuple[float, float]:
    denominator_01 = counts["n00"] + counts["n01"]
    denominator_11 = counts["n10"] + counts["n11"]
    pi01 = counts["n01"] / denominator_01 if denominator_01 else np.nan
    pi11 = counts["n11"] / denominator_11 if denominator_11 else np.nan
    return pi01, pi11


def bootstrap_markov_group(
    state_counts: pd.DataFrame,
    reps: int,
    rng: np.random.Generator,
) -> dict[str, float | int | None]:
    state_rows = state_counts[["n00", "n01", "n10", "n11"]].to_numpy(dtype=int)
    n_states = len(state_rows)
    pi01_values: list[float] = []
    pi11_values: list[float] = []
    for _ in range(reps):
        sample = state_rows[rng.integers(0, n_states, size=n_states)]
        total = sample.sum(axis=0)
        counts = dict(zip(["n00", "n01", "n10", "n11"], total.tolist()))
        pi01, pi11 = transition_probabilities(counts)
        if np.isfinite(pi01):
            pi01_values.append(pi01)
        if np.isfinite(pi11):
            pi11_values.append(pi11)

    def interval(values: list[float]) -> tuple[float | None, float | None]:
        if not values:
            return None, None
        return tuple(np.quantile(values, [0.025, 0.975]).tolist())

    pi01_lo, pi01_hi = interval(pi01_values)
    pi11_lo, pi11_hi = interval(pi11_values)
    return {
        "pi01_lo": pi01_lo,
        "pi01_hi": pi01_hi,
        "pi11_lo": pi11_lo,
        "pi11_hi": pi11_hi,
        "pi01_valid_bootstraps": len(pi01_values),
        "pi11_valid_bootstraps": len(pi11_values),
    }


def markov_for_threshold(
    panel: pd.DataFrame,
    tau: float,
    reps: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    state_records: list[dict[str, Any]] = []
    for (climate, state), state_frame in panel.groupby(["climate_family", "state"], observed=True):
        counts = state_transition_counts(state_frame, tau)
        pi01, pi11 = transition_probabilities(counts)
        state_records.append(
            {
                "tau": tau,
                "climate_family": str(climate),
                "state": state,
                **counts,
                "pi01": pi01,
                "pi11": pi11,
            }
        )
    state_table = pd.DataFrame(state_records)
    group_rows: list[dict[str, Any]] = []
    rng = np.random.default_rng(seed)
    for climate, group in state_table.groupby("climate_family", observed=True):
        totals = group[["n00", "n01", "n10", "n11", "valid_pairs"]].sum().astype(int)
        counts = totals.to_dict()
        pi01, pi11 = transition_probabilities(counts)
        bootstrap = bootstrap_markov_group(group, reps, rng)
        group_rows.append(
            {
                "tau": tau,
                "climate_family": climate,
                "n_states": group["state"].nunique(),
                **counts,
                "pi01": pi01,
                "pi11": pi11,
                **bootstrap,
            }
        )
    group_table = pd.DataFrame(group_rows).sort_values("climate_family")
    total_counts = int(group_table[["n00", "n01", "n10", "n11"]].to_numpy().sum())
    valid_pairs = int(state_table["valid_pairs"].sum())
    if total_counts != valid_pairs:
        raise AssertionError(f"Transition validation failed at tau={tau}: counts={total_counts}, pairs={valid_pairs}")
    maximum_pairs = int(panel.groupby("state")["month"].count().sub(1).clip(lower=0).sum())
    if valid_pairs > maximum_pairs:
        raise AssertionError("Valid transition pairs exceed the mathematical maximum.")
    validation = {
        "tau": tau,
        "total_transition_counts": total_counts,
        "valid_adjacent_state_month_pairs": valid_pairs,
        "maximum_possible_given_rows": maximum_pairs,
        "validated": True,
    }
    return state_table, group_table, validation


def run_markov_analyses(panel: pd.DataFrame, output_dir: Path, config: RunConfig) -> dict[str, Any]:
    markov_dir = output_dir / "markov"
    markov_dir.mkdir(parents=True, exist_ok=True)
    all_groups: list[pd.DataFrame] = []
    validations: list[dict[str, Any]] = []
    primary_state = pd.DataFrame()
    primary_group = pd.DataFrame()

    for threshold_index, tau in enumerate(config.thresholds):
        state_table, group_table, validation = markov_for_threshold(
            panel,
            tau=tau,
            reps=config.bootstrap_reps,
            seed=config.random_seed + 1000 * threshold_index,
        )
        state_table.to_csv(markov_dir / f"markov_state_tau_{safe_slug(f'{tau:g}')}.csv", index=False)
        group_table.to_csv(markov_dir / f"markov_climate_tau_{safe_slug(f'{tau:g}')}.csv", index=False)
        all_groups.append(group_table)
        validations.append(validation)
        if math.isclose(tau, config.primary_threshold, rel_tol=0, abs_tol=1e-12):
            primary_state, primary_group = state_table, group_table

    if primary_group.empty:
        raise ValueError("Primary threshold is not included in the threshold list.")
    combined = pd.concat(all_groups, ignore_index=True)
    combined.to_csv(markov_dir / "markov_threshold_sensitivity.csv", index=False)
    write_json(markov_dir / "markov_validation.json", validations)
    console_table(f"State-level Markov results at tau={config.primary_threshold:g}", primary_group)

    latex_primary = primary_group.copy()
    latex_primary["pi01 (95% CI)"] = latex_primary.apply(
        lambda row: f"{row.pi01:.2f} ({row.pi01_lo:.2f}, {row.pi01_hi:.2f})" if pd.notna(row.pi01_lo) else "--",
        axis=1,
    )
    latex_primary["pi11 (95% CI)"] = latex_primary.apply(
        lambda row: f"{row.pi11:.2f} ({row.pi11_lo:.2f}, {row.pi11_hi:.2f})" if pd.notna(row.pi11_lo) else "--",
        axis=1,
    )
    save_frame(
        latex_primary[["climate_family", "n_states", "n00", "n01", "n10", "n11", "valid_pairs", "pi01 (95% CI)", "pi11 (95% CI)"]],
        "markov_primary",
        output_dir,
        caption=f"State-level Markov transition counts and state-cluster bootstrap intervals at tau={config.primary_threshold:g}.",
        label="tab:markov_primary",
    )
    save_frame(
        combined[["tau", "climate_family", "n_states", "n00", "n01", "n10", "n11", "pi01", "pi01_lo", "pi01_hi", "pi11", "pi11_lo", "pi11_hi"]],
        "markov_threshold_sensitivity",
        output_dir,
        caption="State-level Markov transition sensitivity across elevated-hotspot thresholds.",
        label="tab:markov_thresholds",
    )

    for probability in ("pi11", "pi01"):
        plt.figure(figsize=(8, 5))
        for climate, group in combined.groupby("climate_family"):
            plt.plot(group["tau"], group[probability], marker="o", label=climate)
        plt.xlabel("Elevated-hotspot threshold")
        plt.ylabel(probability)
        plt.ylim(-0.03, 1.03)
        plt.title(f"Threshold sensitivity of {probability}")
        plt.legend(fontsize=8)
        finish_plot(output_dir / "figures" / f"markov_{probability}_threshold.png", config.show_plots)

    return {
        "primary_state": primary_state,
        "primary_group": primary_group,
        "all_thresholds": combined,
        "validations": validations,
    }


# ---------------------------------------------------------------------------
# Empirical-logit PCA and parsimonious GMM clustering
# ---------------------------------------------------------------------------

def empirical_logit_trajectory(panel: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series, pd.DataFrame]:
    complete_states = (
        panel.groupby("state", observed=True)["month"].nunique().loc[lambda x: x == len(MONTH_ORDER)].index
    )
    excluded_states = sorted(set(panel["state"]) - set(complete_states))
    if excluded_states:
        LOGGER.warning("Excluding incomplete trajectories from clustering: %s", excluded_states)
    complete = panel.loc[panel["state"].isin(complete_states)].copy()
    prop = complete.pivot(index="state", columns="month", values="prop").reindex(columns=MONTH_ORDER)
    n_lookup = complete.groupby("state")["N_s"].first().reindex(prop.index)
    empirical_prop = prop.mul(n_lookup, axis=0).add(0.5).div(n_lookup.add(1), axis=0)
    empirical_prop = empirical_prop.clip(1e-8, 1 - 1e-8)
    empirical_logit = np.log(empirical_prop / (1 - empirical_prop))
    return empirical_logit, n_lookup, pd.DataFrame({"excluded_state": excluded_states})


def fit_gmm_grid(scores: np.ndarray, max_clusters: int, seed: int, n_init: int = 10) -> tuple[pd.DataFrame, dict[int, GaussianMixture]]:
    models: dict[int, GaussianMixture] = {}
    rows: list[dict[str, Any]] = []
    maximum = min(max_clusters, len(scores) - 1)
    for k in range(1, maximum + 1):
        model = GaussianMixture(
            n_components=k,
            covariance_type="diag",
            n_init=n_init,
            reg_covar=1e-6,
            random_state=seed + k,
            max_iter=1000,
        ).fit(scores)
        probability = np.clip(model.predict_proba(scores), 1e-15, 1)
        entropy = float(-np.sum(probability * np.log(probability)))
        labels = model.predict(scores)
        cluster_sizes = np.bincount(labels, minlength=k)
        rows.append(
            {
                "K": k,
                "covariance": "diag",
                "BIC": model.bic(scores),
                "ICL": model.bic(scores) + 2 * entropy,
                "entropy": entropy,
                "minimum_cluster_size": int(cluster_sizes.min()),
                "cluster_sizes": ";".join(map(str, sorted(cluster_sizes.tolist()))),
                "converged": bool(model.converged_),
            }
        )
        models[k] = model
    return pd.DataFrame(rows), models


def select_parsimonious_k(selection: pd.DataFrame, minimum_cluster_size: int) -> int:
    feasible = selection[(selection["K"] >= 2) & (selection["minimum_cluster_size"] >= minimum_cluster_size)]
    if feasible.empty:
        LOGGER.warning("No non-degenerate K>=2 solution met minimum cluster size %d; retaining K=1.", minimum_cluster_size)
        return 1
    return int(feasible.sort_values(["BIC", "K"]).iloc[0]["K"])


def initialization_stability(
    scores: np.ndarray,
    reference_labels: np.ndarray,
    k: int,
    runs: int,
    seed: int,
) -> pd.DataFrame:
    records: list[dict[str, Any]] = []
    for run in range(runs):
        model = GaussianMixture(
            n_components=k,
            covariance_type="diag",
            n_init=1,
            reg_covar=1e-6,
            random_state=seed + 10_000 + run,
            max_iter=1000,
        ).fit(scores)
        labels = model.predict(scores)
        records.append(
            {
                "run": run,
                "ARI": adjusted_rand_score(reference_labels, labels),
                "converged": bool(model.converged_),
                "minimum_cluster_size": int(np.bincount(labels, minlength=k).min()),
            }
        )
    return pd.DataFrame(records)


def bootstrap_cluster_stability(
    scores: np.ndarray,
    reference_labels: np.ndarray,
    k: int,
    reps: int,
    seed: int,
) -> tuple[pd.DataFrame, np.ndarray]:
    rng = np.random.default_rng(seed)
    n = len(scores)
    cocluster = np.zeros((n, n), dtype=float)
    records: list[dict[str, Any]] = []
    for rep in range(reps):
        sample_indices = rng.integers(0, n, size=n)
        model = GaussianMixture(
            n_components=k,
            covariance_type="diag",
            n_init=2,
            reg_covar=1e-6,
            random_state=seed + 20_000 + rep,
            max_iter=1000,
        ).fit(scores[sample_indices])
        labels = model.predict(scores)
        cocluster += (labels[:, None] == labels[None, :])
        records.append(
            {
                "replicate": rep,
                "ARI": adjusted_rand_score(reference_labels, labels),
                "minimum_cluster_size": int(np.bincount(labels, minlength=k).min()),
                "converged": bool(model.converged_),
            }
        )
    cocluster /= reps
    return pd.DataFrame(records), cocluster


def run_clustering(panel: pd.DataFrame, output_dir: Path, config: RunConfig) -> dict[str, Any]:
    cluster_dir = output_dir / "clustering"
    cluster_dir.mkdir(parents=True, exist_ok=True)
    empirical_logit, denominators, excluded = empirical_logit_trajectory(panel)
    excluded.to_csv(cluster_dir / "excluded_incomplete_states.csv", index=False)

    scaler = StandardScaler()
    standardized = scaler.fit_transform(empirical_logit)
    pca = PCA(n_components=config.pca_variance, svd_solver="full", random_state=config.random_seed)
    scores = pca.fit_transform(standardized)
    selection, models = fit_gmm_grid(scores, config.max_clusters, config.random_seed)
    selected_k = select_parsimonious_k(selection, config.minimum_cluster_size)
    selected_model = models[selected_k]
    labels = selected_model.predict(scores)
    states = empirical_logit.index.to_numpy()
    membership = pd.DataFrame({"state": states, "cluster": labels})
    membership.to_csv(cluster_dir / "gmm_membership.csv", index=False)
    selection["selected"] = selection["K"].eq(selected_k)
    selection.to_csv(cluster_dir / "gmm_selection.csv", index=False)

    init = initialization_stability(scores, labels, selected_k, config.init_stability_runs, config.random_seed)
    init.to_csv(cluster_dir / "gmm_initialization_stability.csv", index=False)
    bootstrap, cocluster = bootstrap_cluster_stability(
        scores,
        labels,
        selected_k,
        config.cluster_bootstrap_reps,
        config.random_seed,
    )
    bootstrap.to_csv(cluster_dir / "gmm_state_bootstrap_stability.csv", index=False)
    cocluster_frame = pd.DataFrame(cocluster, index=states, columns=states)
    cocluster_frame.to_csv(cluster_dir / "gmm_coclustering_matrix.csv")

    same_cluster = labels[:, None] == labels[None, :]
    diagonal = np.eye(len(labels), dtype=bool)
    within = cocluster[same_cluster & ~diagonal]
    between = cocluster[~same_cluster]
    summary = {
        "n_states": len(states),
        "n_months": empirical_logit.shape[1],
        "n_components_pca": int(pca.n_components_),
        "pca_explained_variance": float(pca.explained_variance_ratio_.sum()),
        "selected_K": selected_k,
        "selection_rule": f"Minimum BIC among K>=2 with minimum cluster size >= {config.minimum_cluster_size}",
        "cluster_sizes": membership.groupby("cluster")["state"].count().sort_index().to_dict(),
        "initialization_ARI_median": float(init["ARI"].median()),
        "initialization_ARI_minimum": float(init["ARI"].min()),
        "bootstrap_ARI_median": float(bootstrap["ARI"].median()),
        "bootstrap_ARI_q025": float(bootstrap["ARI"].quantile(0.025)),
        "bootstrap_ARI_minimum": float(bootstrap["ARI"].min()),
        "mean_within_reference_cluster_coclustering": float(np.mean(within)) if len(within) else None,
        "mean_between_reference_cluster_coclustering": float(np.mean(between)) if len(between) else None,
    }
    write_json(cluster_dir / "gmm_stability_summary.json", summary)
    console_table("GMM model selection", selection)
    console_table("Selected GMM membership", membership)

    save_frame(
        selection,
        "gmm_selection",
        output_dir,
        caption="Diagonal Gaussian-mixture selection and non-degeneracy diagnostics.",
        label="tab:gmm_selection",
    )
    save_frame(
        membership.sort_values(["cluster", "state"]),
        "gmm_membership",
        output_dir,
        caption="Membership under the selected parsimonious descriptive mixture.",
        label="tab:gmm_membership",
    )

    plt.figure(figsize=(7, 5))
    plt.plot(selection["K"], selection["BIC"], marker="o", label="BIC")
    plt.plot(selection["K"], selection["ICL"], marker="o", label="ICL")
    plt.axvline(selected_k, linestyle="--", label=f"Selected K={selected_k}")
    plt.xlabel("Number of mixture components K")
    plt.ylabel("Criterion (lower is better)")
    plt.title("Parsimonious Gaussian-mixture selection")
    plt.legend()
    finish_plot(output_dir / "figures" / "gmm_bic_icl.png", config.show_plots)

    prop_wide = panel.pivot(index="state", columns="month", values="prop").reindex(index=states, columns=MONTH_ORDER)
    for cluster in sorted(membership["cluster"].unique()):
        cluster_states = membership.loc[membership["cluster"].eq(cluster), "state"]
        cluster_values = prop_wide.loc[cluster_states]
        plt.figure(figsize=(8, 5))
        for state, row in cluster_values.iterrows():
            plt.plot(MONTH_ORDER, row.to_numpy(dtype=float), alpha=0.35, linewidth=1)
        plt.plot(MONTH_ORDER, cluster_values.mean(axis=0), linewidth=3, label="Cluster mean")
        plt.xticks(rotation=45)
        plt.ylabel("Reported hotspot proportion")
        plt.title(f"Descriptive cluster {cluster}: {len(cluster_states)} state/UT units")
        plt.legend()
        finish_plot(output_dir / "figures" / f"cluster_{cluster}_trajectories.png", config.show_plots)

    return {
        "selection": selection,
        "membership": membership,
        "initialization": init,
        "bootstrap": bootstrap,
        "coclustering": cocluster_frame,
        "summary": summary,
    }


# ---------------------------------------------------------------------------
# Coverage summaries, manuscript macros, and archive
# ---------------------------------------------------------------------------

def create_coverage_tables(panel: pd.DataFrame, output_dir: Path) -> pd.DataFrame:
    coverage = (
        panel.groupby(["state", "climate", "climate_family"], observed=True, as_index=False)
        .agg(
            N_s=("N_s", "first"),
            months_observed=("prop", "count"),
            mean_prop=("prop", "mean"),
            lat_centroid=("lat_centroid", "first") if "lat_centroid" in panel.columns else ("prop", lambda x: np.nan),
            lon_centroid=("lon_centroid", "first") if "lon_centroid" in panel.columns else ("prop", lambda x: np.nan),
        )
        .sort_values("state")
    )
    save_frame(
        coverage,
        "coverage_by_state",
        output_dir,
        caption="Matched state/UT coverage, source climatic label, grouped climatic family, district denominator, and observed months.",
        label="tab:coverage",
    )
    climate_summary = (
        coverage.groupby("climate_family", observed=True, as_index=False)
        .agg(
            n_states=("state", "count"),
            minimum_N=("N_s", "min"),
            maximum_N=("N_s", "max"),
            mean_state_prop=("mean_prop", "mean"),
            median_state_prop=("mean_prop", "median"),
        )
    )
    save_frame(
        climate_summary,
        "coverage_by_climate_family",
        output_dir,
        caption="Coverage summary by grouped climatic family.",
        label="tab:coverage_climate",
    )
    console_table("Coverage by state/UT", coverage)
    return coverage


def macro_name(label: str) -> str:
    return re.sub(r"[^A-Za-z]", "", label)


def create_manuscript_outputs(
    panel: pd.DataFrame,
    gee: dict[str, Any],
    rounding: dict[str, Any],
    influence: dict[str, pd.DataFrame],
    markov: dict[str, Any],
    clustering: dict[str, Any],
    output_dir: Path,
    config: RunConfig,
) -> None:
    manuscript_dir = output_dir / "manuscript_ready"
    manuscript_dir.mkdir(parents=True, exist_ok=True)
    climate = climate_rows(gee["primary_table"]).copy()
    climate["name"] = climate["term"].map(friendly_term).str.replace("Climate: ", "", regex=False)
    omnibus = gee["omnibus"]

    macros = [
        "% Auto-generated. Do not edit numerical values manually.",
        rf"\newcommand{{\RevisionNStates}}{{{panel['state'].nunique()}}}",
        rf"\newcommand{{\RevisionNObs}}{{{len(panel)}}}",
        rf"\newcommand{{\ClimateWaldStatistic}}{{{omnibus['chi2']:.2f}}}",
        rf"\newcommand{{\ClimateWaldDf}}{{{omnibus['df']}}}",
        rf"\newcommand{{\ClimateWaldP}}{{{omnibus['p']:.3g}}}",
        rf"\newcommand{{\PrimaryMarkovThreshold}}{{{config.primary_threshold:g}}}",
        rf"\newcommand{{\SelectedClusterK}}{{{clustering['summary']['selected_K']}}}",
        rf"\newcommand{{\PCAExplainedVariance}}{{{100 * clustering['summary']['pca_explained_variance']:.1f}\%}}",
    ]
    for _, row in climate.iterrows():
        base = macro_name(row["name"])
        macros.extend(
            [
                rf"\newcommand{{\OR{base}}}{{{row['OR']:.2f}}}",
                rf"\newcommand{{\ORLo{base}}}{{{row['OR_lo']:.2f}}}",
                rf"\newcommand{{\ORHi{base}}}{{{row['OR_hi']:.2f}}}",
                rf"\newcommand{{\PValue{base}}}{{{row['p']:.3g}}}",
            ]
        )
    (manuscript_dir / "revision_numeric_macros.tex").write_text("\n".join(macros) + "\n", encoding="utf-8")

    climate_sentences = []
    for _, row in climate.iterrows():
        climate_sentences.append(
            f"{row['name']} (OR {row['OR']:.2f}, 95\\% CI {row['OR_lo']:.2f}--{row['OR_hi']:.2f})"
        )
    snippets = rf"""% Auto-generated manuscript snippets.
\paragraph{{Primary GEE.}}
The denominator-weighted fractional GEE included {panel['state'].nunique()} matched state/UT units and {len(panel)} state-month observations. The climatic-family factor was associated with hotspot burden overall (Mancl--DeRouen Wald $\chi^2_{{{omnibus['df']}}}={omnibus['chi2']:.2f}$, $p={omnibus['p']:.3g}$). Relative to the humid-subtropical reference group, the fitted contrasts were {', '.join(climate_sentences)}.

\paragraph{{Response-construction sensitivity.}}
The floor/round/ceiling analysis produced {len(rounding['summary']['separation_terms'])} flagged climate estimates consistent with quasi-complete separation or numerical instability. The largest absolute coefficient change across all constructions was {rounding['summary']['max_abs_coefficient_change_all']:.2f}; the corresponding non-separated maximum was {rounding['summary']['max_abs_coefficient_change_nonseparated'] if rounding['summary']['max_abs_coefficient_change_nonseparated'] is not None else float('nan'):.2f}. The instability supports retaining the fractional response as primary.

\paragraph{{State-level persistence.}}
At $\tau={config.primary_threshold:g}$, the sum of all four transition counts equalled the number of valid adjacent state-month pairs ({markov['validations'][list(config.thresholds).index(config.primary_threshold)]['valid_adjacent_state_month_pairs']}), confirming that no district-level transitions or non-adjacent gaps were counted. Complete state-cluster bootstrap intervals and threshold sensitivity are reported in the generated tables.

\paragraph{{Descriptive clustering.}}
Empirical-logit trajectories were standardized and projected onto {clustering['summary']['n_components_pca']} principal components explaining {100 * clustering['summary']['pca_explained_variance']:.1f}\% of variation. The non-degenerate selection rule retained $K={clustering['summary']['selected_K']}$. Median ARI was {clustering['summary']['initialization_ARI_median']:.2f} across repeated one-start fits and {clustering['summary']['bootstrap_ARI_median']:.2f} under state bootstrap.
"""
    (manuscript_dir / "revision_results_snippets.tex").write_text(snippets, encoding="utf-8")


def write_versions(output_dir: Path, inputs: Sequence[Path]) -> None:
    payload = {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "statsmodels": statsmodels.__version__,
        "scikit_learn": sklearn.__version__,
        "matplotlib": plt.matplotlib.__version__,
        "patsy": patsy.__version__,
        "inputs": [
            {"path": str(path), "sha256": sha256(path), "size_bytes": path.stat().st_size}
            for path in inputs
            if path is not None and path.exists()
        ],
    }
    write_json(output_dir / "software_and_input_manifest.json", payload)


def archive_output(output_dir: Path) -> Path:
    archive_base = output_dir.parent / f"{output_dir.name}_archive"
    archive_path = Path(shutil.make_archive(str(archive_base), "zip", root_dir=output_dir.parent, base_dir=output_dir.name))
    return archive_path


# ---------------------------------------------------------------------------
# Main orchestration
# ---------------------------------------------------------------------------

def parse_thresholds(text: str) -> tuple[float, ...]:
    values = tuple(sorted(set(float(item.strip()) for item in text.split(",") if item.strip())))
    if not values or any(value <= 0 or value >= 1 for value in values):
        raise argparse.ArgumentTypeError("Thresholds must be comma-separated values strictly between 0 and 1.")
    return values


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--panel-long", type=Path, help="Pre-harmonized long CSV containing state, climate, N_s, month, prop.")
    source.add_argument("--panel-wide", type=Path, help="Wide Excel state-month percentage panel, e.g. Modified Data (1).xlsx.")
    parser.add_argument("--geo", type=Path, help="District geolocation CSV; required with --panel-wide.")
    parser.add_argument("--hotspot-summary", type=Path, help="Optional top-hotspot summary Excel file, e.g. Modified Data (2).xlsx.")
    parser.add_argument("--output", type=Path, default=Path("revision_outputs"))
    parser.add_argument("--primary-threshold", type=float, default=0.01)
    parser.add_argument("--thresholds", type=parse_thresholds, default=parse_thresholds("0.005,0.01,0.02,0.03"))
    parser.add_argument("--bootstrap-reps", type=int, default=1000)
    parser.add_argument("--cluster-bootstrap-reps", type=int, default=100)
    parser.add_argument("--init-stability-runs", type=int, default=30)
    parser.add_argument("--max-clusters", type=int, default=5)
    parser.add_argument("--minimum-cluster-size", type=int, default=3)
    parser.add_argument("--pca-variance", type=float, default=0.90)
    parser.add_argument("--seed", type=int, default=20260714)
    parser.add_argument("--show-plots", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.panel_wide is not None and args.geo is None:
        raise SystemExit("--geo is required when --panel-wide is used.")
    thresholds = tuple(args.thresholds)
    if not any(math.isclose(value, args.primary_threshold, rel_tol=0, abs_tol=1e-12) for value in thresholds):
        thresholds = tuple(sorted(set(thresholds + (args.primary_threshold,))))

    config = RunConfig(
        primary_threshold=args.primary_threshold,
        thresholds=thresholds,
        bootstrap_reps=args.bootstrap_reps,
        cluster_bootstrap_reps=args.cluster_bootstrap_reps,
        init_stability_runs=args.init_stability_runs,
        max_clusters=args.max_clusters,
        minimum_cluster_size=args.minimum_cluster_size,
        pca_variance=args.pca_variance,
        random_seed=args.seed,
        show_plots=args.show_plots,
    )
    output_dir: Path = args.output.resolve()
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True)
    setup_logging(output_dir)
    write_json(output_dir / "config_used.json", asdict(config))
    LOGGER.info("Starting reproducible revision analysis.")

    panel = build_analysis_panel(
        geo_path=args.geo.resolve() if args.geo else None,
        wide_panel_path=args.panel_wide.resolve() if args.panel_wide else None,
        long_panel_path=args.panel_long.resolve() if args.panel_long else None,
        output_dir=output_dir,
        config=config,
    )
    if args.hotspot_summary:
        validate_hotspot_summary(args.hotspot_summary.resolve(), panel, output_dir)
    coverage = create_coverage_tables(panel, output_dir)
    gee = run_gee_analyses(panel, output_dir)
    rounding = run_rounding_sensitivity(panel, gee["primary_table"], output_dir)
    influence = run_influence_analyses(panel, output_dir)
    markov = run_markov_analyses(panel, output_dir, config)
    clustering = run_clustering(panel, output_dir, config)
    create_manuscript_outputs(panel, gee, rounding, influence, markov, clustering, output_dir, config)

    inputs = [path for path in (args.panel_long, args.panel_wide, args.geo, args.hotspot_summary) if path]
    write_versions(output_dir, [path.resolve() for path in inputs])
    archive = archive_output(output_dir)
    LOGGER.info("Analysis complete. Output directory: %s", output_dir)
    LOGGER.info("ZIP archive: %s", archive)
    LOGGER.info("Primary climate omnibus test: chi2(%d)=%.3f, p=%.4g", gee["omnibus"]["df"], gee["omnibus"]["chi2"], gee["omnibus"]["p"])
    LOGGER.info("Selected descriptive cluster K: %d", clustering["summary"]["selected_K"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
