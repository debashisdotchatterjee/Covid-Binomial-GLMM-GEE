#!/usr/bin/env python3
r"""Audit and compile marked/clean LaTeX manuscripts reproducibly.

The utility:
1. creates marked and clean .tex copies by toggling \revtrue / \revfalse;
2. checks duplicate labels and unresolved \ref/\autoref/\eqref/\cref references;
3. checks \includegraphics, \input, \include, and bibliography dependencies;
4. copies unsafe graphics filenames to safe aliases and updates generated copies;
5. optionally compiles both copies with latexmk or pdflatex/bibtex;
6. writes machine-readable JSON and human-readable text reports.

It never deletes the original manuscript or original figure files.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Iterable

LABEL_RE = re.compile(r"\\label\{([^}]+)\}")
REF_RE = re.compile(r"\\(?:ref|autoref|eqref|pageref|cref|Cref)\{([^}]+)\}")
GRAPHICS_RE = re.compile(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}")
INPUT_RE = re.compile(r"\\(?:input|include)\{([^}]+)\}")
BIB_RE = re.compile(r"\\bibliography\{([^}]+)\}")
UNSAFE_RE = re.compile(r"[^A-Za-z0-9._/\-]")


def strip_comments(text: str) -> str:
    cleaned = []
    for line in text.splitlines():
        out = []
        escaped = False
        for char in line:
            if char == "%" and not escaped:
                break
            out.append(char)
            if char == "\\":
                escaped = not escaped
            else:
                escaped = False
        cleaned.append("".join(out))
    return "\n".join(cleaned)


def safe_component(name: str) -> str:
    stem = name.replace("&", "and")
    stem = re.sub(r"\s+", "_", stem)
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem)
    stem = re.sub(r"_+", "_", stem).strip("_")
    return stem or "asset"


def safe_relative_path(rel: str) -> str:
    path = Path(rel)
    return str(Path(*[safe_component(part) for part in path.parts])).replace("\\", "/")


def resolve_graphic(project: Path, rel: str) -> Path | None:
    candidate = project / rel
    if candidate.exists():
        return candidate
    if candidate.suffix:
        return None
    for suffix in (".pdf", ".png", ".jpg", ".jpeg", ".eps"):
        hit = candidate.with_suffix(suffix)
        if hit.exists():
            return hit
    return None


def resolve_tex_dependency(project: Path, rel: str) -> Path | None:
    candidate = project / rel
    if candidate.exists():
        return candidate
    if not candidate.suffix and candidate.with_suffix(".tex").exists():
        return candidate.with_suffix(".tex")
    return None


def run_command(command: list[str], cwd: Path, log: Path) -> int:
    with log.open("a", encoding="utf-8") as stream:
        stream.write("\n$ " + " ".join(command) + "\n")
        process = subprocess.run(command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, text=True)
    return process.returncode


def compile_tex(tex_path: Path, report_dir: Path) -> dict[str, object]:
    log = report_dir / f"compile_{tex_path.stem}.log"
    log.write_text("", encoding="utf-8")
    cwd = tex_path.parent
    if shutil.which("latexmk"):
        code = run_command(
            ["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error", tex_path.name],
            cwd,
            log,
        )
        engine = "latexmk"
    elif shutil.which("pdflatex"):
        engine = "pdflatex/bibtex"
        code = run_command(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", tex_path.name], cwd, log)
        bibs = BIB_RE.findall(strip_comments(tex_path.read_text(encoding="utf-8")))
        if code == 0 and bibs and shutil.which("bibtex"):
            code = run_command(["bibtex", tex_path.stem], cwd, log)
        if code == 0:
            code = run_command(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", tex_path.name], cwd, log)
        if code == 0:
            code = run_command(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", tex_path.name], cwd, log)
    else:
        return {"attempted": False, "success": False, "engine": None, "reason": "No LaTeX engine found."}
    return {
        "attempted": True,
        "success": code == 0,
        "engine": engine,
        "return_code": code,
        "log": str(log),
        "pdf": str(tex_path.with_suffix(".pdf")) if tex_path.with_suffix(".pdf").exists() else None,
    }


def collect_duplicates(items: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    duplicates: set[str] = set()
    for item in items:
        if item in seen:
            duplicates.add(item)
        seen.add(item)
    return sorted(duplicates)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tex", type=Path, required=True, help="Main manuscript .tex file.")
    parser.add_argument("--project-root", type=Path, default=None, help="Root used to resolve figures/inputs.")
    parser.add_argument("--output", type=Path, default=Path("latex_audit_outputs"))
    parser.add_argument("--compile", action="store_true", help="Compile marked and clean copies.")
    parser.add_argument("--strict", action="store_true", help="Return nonzero if unresolved dependencies/references exist.")
    args = parser.parse_args()

    tex = args.tex.resolve()
    if not tex.exists():
        raise SystemExit(f"Missing manuscript: {tex}")
    project = (args.project_root or tex.parent).resolve()
    output = args.output.resolve()
    if output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True)

    original = tex.read_text(encoding="utf-8")
    active = strip_comments(original)
    labels = LABEL_RE.findall(active)
    refs: list[str] = []
    for block in REF_RE.findall(active):
        refs.extend([item.strip() for item in block.split(",") if item.strip()])
    duplicate_labels = collect_duplicates(labels)
    missing_refs = sorted(set(refs) - set(labels))

    graphics = GRAPHICS_RE.findall(active)
    missing_graphics: list[str] = []
    unsafe_graphics: list[dict[str, str]] = []
    replacement_map: dict[str, str] = {}
    for rel in graphics:
        resolved = resolve_graphic(project, rel)
        if resolved is None:
            missing_graphics.append(rel)
            continue
        if UNSAFE_RE.search(rel):
            safe_rel = safe_relative_path(rel)
            if not Path(safe_rel).suffix and resolved.suffix:
                safe_rel = str(Path(safe_rel).with_suffix(resolved.suffix)).replace("\\", "/")
            target = project / safe_rel
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.resolve() != resolved.resolve():
                shutil.copy2(resolved, target)
            replacement_map[rel] = safe_rel
            unsafe_graphics.append({"original": rel, "safe_copy": safe_rel})

    missing_inputs = [rel for rel in INPUT_RE.findall(active) if resolve_tex_dependency(project, rel) is None]
    missing_bibliographies: list[str] = []
    for block in BIB_RE.findall(active):
        for bib in [item.strip() for item in block.split(",") if item.strip()]:
            candidate = project / (bib if bib.endswith(".bib") else bib + ".bib")
            if not candidate.exists():
                missing_bibliographies.append(str(candidate.relative_to(project)))

    marked = original.replace("\\revfalse", "\\revtrue")
    clean = original.replace("\\revtrue", "\\revfalse")
    for old, new in replacement_map.items():
        marked = marked.replace("{" + old + "}", "{" + new + "}")
        clean = clean.replace("{" + old + "}", "{" + new + "}")

    marked_path = project / f"{tex.stem}_marked.tex"
    clean_path = project / f"{tex.stem}_clean.tex"
    marked_path.write_text(marked, encoding="utf-8")
    clean_path.write_text(clean, encoding="utf-8")

    report: dict[str, object] = {
        "source": str(tex),
        "project_root": str(project),
        "marked_tex": str(marked_path),
        "clean_tex": str(clean_path),
        "number_of_labels": len(labels),
        "number_of_references": len(refs),
        "duplicate_labels": duplicate_labels,
        "missing_references": missing_refs,
        "missing_graphics": sorted(set(missing_graphics)),
        "unsafe_graphics_copied": unsafe_graphics,
        "missing_inputs": sorted(set(missing_inputs)),
        "missing_bibliographies": sorted(set(missing_bibliographies)),
    }
    if args.compile:
        report["marked_compile"] = compile_tex(marked_path, output)
        report["clean_compile"] = compile_tex(clean_path, output)

    (output / "latex_audit_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    lines = [
        f"Source: {tex}",
        f"Marked copy: {marked_path}",
        f"Clean copy: {clean_path}",
        f"Duplicate labels: {duplicate_labels or 'none'}",
        f"Missing references: {missing_refs or 'none'}",
        f"Missing graphics: {sorted(set(missing_graphics)) or 'none'}",
        f"Missing inputs: {sorted(set(missing_inputs)) or 'none'}",
        f"Missing bibliographies: {sorted(set(missing_bibliographies)) or 'none'}",
        f"Unsafe graphics copied: {unsafe_graphics or 'none'}",
    ]
    (output / "latex_audit_report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))

    failures = duplicate_labels or missing_refs or missing_graphics or missing_inputs or missing_bibliographies
    if args.compile:
        failures = failures or not report["marked_compile"].get("success", False) or not report["clean_compile"].get("success", False)
    return 1 if args.strict and failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
