# Manuscript integration

After a successful analysis run, copy or `\input{}` the generated files from:

- `revision_outputs/manuscript_ready/revision_numeric_macros.tex`
- `revision_outputs/manuscript_ready/revision_results_snippets.tex`
- `revision_outputs/tables/tex/`

The generated numerical macros prevent manual transcription errors when updating the marked manuscript.

To generate and audit marked and clean manuscripts:

```bash
python analysis/latex_audit.py \
  --tex manuscript/main.tex \
  --project-root manuscript \
  --output latex_audit_outputs \
  --compile --strict
```

The audit utility does not delete original graphics. Unsafe filenames are copied to safe aliases and only the generated marked/clean `.tex` copies are updated.
